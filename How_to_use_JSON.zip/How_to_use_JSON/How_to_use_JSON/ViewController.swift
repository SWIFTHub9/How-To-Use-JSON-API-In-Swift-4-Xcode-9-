//
//  ViewController.swift
//  How_to_use_JSON
//
//  Created by Abhishek Verma on 11/12/17.
//  Copyright © 2017 SWIFT HUB. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let  Url = URL(string: "https://raw.githubusercontent.com/Abhishekverma99/Use-swift-3.0/master/db.json")
        Alamofire.request(Url!).validate().responseJSON { (response) in
            if ((response.result.value) != nil) {
                let jsondata = JSON(response.result.value!)
                print(jsondata)
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

